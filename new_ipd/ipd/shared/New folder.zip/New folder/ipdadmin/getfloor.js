import { atom } from "recoil";

// Appointment Table
export const getfloor = atom({
    key: "getfloor",
    default: {
       block:0
    },
});

